﻿using System;

using SolarWinds.APM.Web;

public partial class Orion_APM_Controls_Views_TopRightPageLinks : System.Web.UI.UserControl
{
    public string CustomizeViewHref { get; set; }

    public string EditNetObjectHref { get; set; }

    public string EditNetObjectText { get; set; }

    public string HelpUrlFragment { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        // customize
        if (Profile.AllowCustomize && !string.IsNullOrWhiteSpace(CustomizeViewHref))
        {
            this.lnkCustomize.NavigateUrl = CustomizeViewHref;
            this.lnkCustomize.Text = Resources.APMWebContent.APMWEBDATA_TM0_1;
        }
        else
        {
            this.lnkCustomize.Visible = false;
        }

        // edit
        if (ApmRoleAccessor.AllowAdmin && !string.IsNullOrWhiteSpace(EditNetObjectHref))
        {
            this.lnkEditNetObject.NavigateUrl = EditNetObjectHref;
            this.lnkEditNetObject.Text = string.IsNullOrWhiteSpace(EditNetObjectText) ? "Edit" : EditNetObjectText;	//TODO localization
        }
        else
        {
            this.lnkEditNetObject.Visible = false;
        }

        // datetime
        this.lblDateTime.Text = DateTime.Now.ToString("F");

        // help
        this.btnHelp.HelpUrlFragment = HelpUrlFragment;
    }

}