﻿using System;
using System.ComponentModel;

using SolarWinds.APM.Common.Extensions.System;
using SolarWinds.Orion.Web;

using Pair = System.Collections.Generic.KeyValuePair<System.String, System.String>;

public partial class Orion_APM_Controls_BreadcrumbBar : System.Web.UI.UserControl
{
	#region Properties

	public string Provider
	{
		get { return ctrSiteMapPath.Provider; }
		set { ctrSiteMapPath.Provider = value; }
	}

    public string SiteMapFilePath
    {
        get { return ctrSiteMapPath.SiteMapFilePath; }
        set { ctrSiteMapPath.SiteMapFilePath = value; }
    }

	#endregion 

	#region Event Handlers

	protected void OnSiteMapPath_OnInit(Object sender, EventArgs e)
	{
		this.Visible = !CommonWebHelper.IsBreadcrumbsDisabled || ctrSiteMapPath.Provider.IsValid();

		if (this.Visible)
		{
            ISiteMapRenderer renderer;

            switch (this.Provider)
            {
                case "SqlBlackBoxSitemapProvider": 
                    renderer = new SolarWinds.APM.BlackBox.Sql.Web.UI.SqlBlackBoxSiteMapRenderer();
                    break;
                case "ExchangeSiteMapProvider":
                    renderer = new SolarWinds.APM.BlackBox.Exchg.Web.UI.ExchangeSiteMapRenderer();
                    break;
                case "IisSiteMapProvider":
                    renderer = new SolarWinds.APM.BlackBox.IIS.Web.UI.IisSiteMapRenderer();
                    break;
                default:
                    renderer = new SolarWinds.Orion.NPM.Web.UI.AdminSiteMapRenderer();
                    break;
            }

			renderer.SetUpData(
				new Pair("ViewID", Request["ViewID"].IsValid() ? Request["ViewID"] : null),
                new Pair("NetObject", Request["NetObject"].IsValid() ? Request["NetObject"] : null),
				new Pair("ReturnTo", Request["ReturnTo"].IsValid() ? Request["ReturnTo"] : null),
				new Pair("AccountID", Request["AccountID"].IsValid() ? Request["AccountID"] : null));

			ctrSiteMapPath.SetUpRenderer(renderer);
		}
	}

	#endregion
}
