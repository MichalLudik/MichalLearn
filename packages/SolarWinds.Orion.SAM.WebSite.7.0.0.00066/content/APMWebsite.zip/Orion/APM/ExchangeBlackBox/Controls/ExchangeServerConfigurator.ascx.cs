﻿using System;

public partial class Orion_APM_ExchangeBlackBox_Controls_ExchangeServerConfigurator : System.Web.UI.UserControl
{
	protected void Page_Load(object sender, EventArgs e)
	{

	}
}