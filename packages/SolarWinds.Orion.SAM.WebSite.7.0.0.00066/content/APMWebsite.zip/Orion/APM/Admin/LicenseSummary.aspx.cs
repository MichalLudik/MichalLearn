using System;
using System.Data;
using System.Web.UI;
using SolarWinds.APM.Common;
using SolarWinds.APM.Web;
using SolarWinds.APM.Common.Utility;

public partial class Orion_APM_Admin_LicenseSummary : Page
{
    private DataTable summaryData;

    protected void Page_Load(object sender, EventArgs e)
    {
        this.Title = InvariantString.Format(Resources.APMWebContent.APMWEBCODE_AK1_20, ApmConstants.ModuleShortName);

        if (!IsPostBack)
        {
            LoadSummary();
        }
    }

    private void LoadSummary()
    {
        using (IAPMBusinessLayer businessLayer = ServiceLocatorForWeb.GetServiceForWeb<IBusinessLayerFactory>().Create())
        {
            summaryData = businessLayer.GetLicenseSummary();
        }
    }

    protected string GetLicenseInfo(string key)
    {
        try
        {
            return summaryData.Rows[0][key].ToString();
        }
        catch(Exception)
        {}

        return "&nbsp;";
    }
}
