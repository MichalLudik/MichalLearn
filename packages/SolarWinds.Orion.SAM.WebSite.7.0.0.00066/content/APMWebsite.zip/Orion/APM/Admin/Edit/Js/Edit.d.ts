declare module SW.APM.EditApp {

    interface ModelInterface {
        getComponentTemplate(templateId: number): TemplateInterface;
        haveTemplate(): boolean;
    }

    interface ComponentInterface {
        TemplateId: number;
    }

    interface TemplateInterface {

    }

}

declare module SW.APM.EditApp.Editors {
    enum EditPropertyType {
        template,
        settings,
        threshold,
        transform
    }

    interface FieldInterface {
        id?: string;
        name?: string;
    }
    interface FieldMapInterface {
        template?: FieldInterface[];
        settings?: FieldInterface[];
        threshold?: FieldInterface[];
        transform?: FieldInterface[];
    }

    interface PropertyInterface {
        name: string;
        suffix?: string;
        type: EditPropertyType;
        readonly?: boolean;
    }

    interface InitSingleInterface {
        cmp: ComponentInterface;
        cmpId: number;
        template: TemplateInterface;
        props?: PropertyInterface[];
    }

    interface UpdateSingleInterface {
        cmp: ComponentInterface;
        cmpId: number;
        isTemplate: boolean;
        props?: PropertyInterface[];
    }

    interface InitMultiInterface extends InitSingleInterface {
        cmpIds: number[];
    }

    interface UpdateMultiInterface extends UpdateSingleInterface {
        cmpIds: number[];
    }

    function parseBool(value: string): boolean;
    function parseId(value: string): number;
    function parseList(value: string): string[];

    function initProps(fields: FieldMapInterface): PropertyInterface[];
    function initPropsThr(names: string[]): PropertyInterface[];

    function chunkInitSingle(opts: InitSingleInterface, items?: PropertyInterface[]);
    function chunkUpdateSingle(opts: UpdateSingleInterface, items?: PropertyInterface[]);

    function chunkInitMulti(opts: InitMultiInterface, items?: PropertyInterface[]);
    function chunkUpdateMulti(opts: UpdateMultiInterface, items?: PropertyInterface[]);
}

declare module SW.APM.EditApp.Grid {
    interface ModelHandler {
        (model: ModelInterface);
    }

    function registerEditor(cmpId: number, onLoad: ModelHandler, onSave: ModelHandler);
}
