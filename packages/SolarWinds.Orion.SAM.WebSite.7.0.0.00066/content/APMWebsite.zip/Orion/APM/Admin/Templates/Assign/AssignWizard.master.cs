﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using SolarWinds.APM.Web.UI;


public partial class Orion_APM_Admin_Templates_Assign_AssignWizard : System.Web.UI.MasterPage
{
    
}
