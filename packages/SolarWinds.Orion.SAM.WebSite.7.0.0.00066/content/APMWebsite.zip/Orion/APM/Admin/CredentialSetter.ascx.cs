﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;

using SolarWinds.APM.Common;
using SolarWinds.APM.Common.Extensions.System;
using SolarWinds.APM.Common.Models;
using SolarWinds.APM.Web;
using SolarWinds.APM.Web.UI;

public partial class Orion_APM_Admin_CredentialSetter : System.Web.UI.UserControl
{
	#region Fields

	private List<SelectNodeTreeItem> selNodesInfo, selTemplatesInfo;
	private List<ComponentBase> selComponentsInfo;

    private string selectedNodeTypes = string.Empty;

	private String key;

	private ListItem
        CredCore = new ListItem(@"{0} <a style=""font-weight:normal;font-size:8pt;color:#369;text-decoration:none;"" target=""_blank"" href=""{1}"">&#0187; {2}</a>"
            .FormatInvariant(Resources.APMWebContent.APMWEBCODE_AK1_98,
            HelpLocator.CreateHelpUrl("SAMAGAgentInheritCredsWDTM"),
            Resources.APMWebContent.APMWEBDATA_WhatDoesThisMean) , "1"),
        CredTemplate = new ListItem(Resources.APMWebContent.APMWEBCODE_AK1_99, "2"),
        CredApplication = new ListItem(Resources.APMWebContent.APMWEBCODE_AK1_100, "2"),
        CredCustom = new ListItem(Resources.APMWebContent.APMWEBCODE_AK1_101, "3");

	#endregion 

	#region Public Properties

	public String CredentialOwner { get; set; }

    public bool ApplicationMode { get; set; }

    public bool AlwaysShown { get; set; }

    public int CredentialSetId
    {
        get
        {
            var id = ComponentBase.TemplateCredentialsId;
            if (ctrCredsTypes.SelectedValue == CredCustom.Value)
            {
                id = ctrCreds.SelectedCredentialSetId;
            }
            else if (ctrCredsTypes.SelectedValue == CredCore.Value)
            {
                id = ComponentBase.NodeWmiCredentialsId;
            }
            return id;
        }
    }

    public List<SelectNodeTreeItem> SelectedNodesInfo
	{
		get
		{
            if (AlwaysShown && selNodesInfo == null)
            {
                selNodesInfo = new List<SelectNodeTreeItem>();
            }
		    if (Visible)
			{
                selNodesInfo.ForEach(item => item.CredentialId = CredentialSetId);
			}
			return selNodesInfo;
		}
		set
		{
            Visible = value != null && value.Count > 0;

            if (Visible)
		    {
		        var query = @"
SELECT NodeID, ObjectSubType
FROM Orion.Nodes
WHERE NodeID IN ({0})
".FormatInvariant(String.Join(",", value.Select(item => item.Id.ToString(CultureInfo.InvariantCulture)).ToArray()));

		        var nodes = SwisProxy.ExecuteQuery(query)
		            .Select("ObjectSubType {0} IN('WMI','Agent')".FormatInvariant(IsCoreCred ? "" : "NOT"));

		        selNodesInfo = value
		            .Where(item => nodes.Contains(r => (int) r[0] == item.Id))
		            .Select(item => new SelectNodeTreeItem(item.Id, item.Name, item.Status))
		            .ToList();

                ctrExpander.Enabled = selNodesInfo.Any();

		        if (AlwaysShown)
		        {
		            Visible = true;
		            selectedNodeTypes = DefaultNodeTypes;
		        }
		        else
		        {
		            Visible = ctrExpander.Enabled;
		            selectedNodeTypes = string.Join(" &amp; ", nodes.Select(r => r[1].ToString()).Distinct());
		        }
		    } 
            else if (AlwaysShown)
            {
                Visible = true;
                ctrExpander.Enabled = false;
                selectedNodeTypes = DefaultNodeTypes;
            }
		}
	}

	public List<SelectNodeTreeItem> SelectedTemplatesInfo
	{
		get 
		{
			if (Visible) 
			{
				selTemplatesInfo = selTemplatesInfo ?? new List<SelectNodeTreeItem>();
			}
			return selTemplatesInfo;
		}
		set { selTemplatesInfo = value; } 
	}

	public List<ComponentBase> SelectedComponentsInfo
	{
		get 
		{
			if (Visible)
			{
				selComponentsInfo = selComponentsInfo ?? new List<ComponentBase>();
			}
			return selComponentsInfo;
		}
		set { selComponentsInfo = value; }
	}

	public Boolean IsValid
	{
		get
		{
			if (Visible)
			{
				if (ctrCredsTypes.SelectedItem.Value == CredCustom.Value)
				{
					Page.Validate(ctrCreds.ValidationGroupName);
	
					return ctrCreds.IsValid;
				}
			}
			return true;
		}
	}

    public Boolean HideTestControl { get; set; }

	#endregion

	#region Helper Internal Properties

	private String Key 
	{
		get 
		{
			if (key.IsNotValid()) 
			{
				var hash = Page.GetType().Name.ToLowerInvariant().GetHashCode()
					.ToString(System.Globalization.CultureInfo.InvariantCulture)
					.Replace('-', 'F');
				if (IsCoreCred)
				{
					return (key = "KeyTR_{0}Core".FormatInvariant(hash));
				}
				return (key = "KeyTR_{0}Apm".FormatInvariant(hash));
			}
			return key;
		}
	}

	private Boolean IsCoreCred
	{
		get { return "Core".Equals(CredentialOwner, StringComparison.InvariantCultureIgnoreCase); }
	}

	protected String Title
	{
		get
		{
			if (Visible)
			{
			    var count = SelectedNodesInfo.Count;
                var nodeS = (count == 1) ? Resources.APMWebContent.APMWEBDATA_NodeSingle : Resources.APMWebContent.APMWEBDATA_NodePlural;
			    return Resources.APMWebContent.APMWEBCODE_AK1_26.FormatInvariant(nodeS, count, selectedNodeTypes);
			}
			return null;
		}
	}

	protected String SubTitle
	{
		get
		{
			if (Visible)
			{
                var name = Resources.APMWebContent.APMWEBCODE_AK1_29;
				if (SelectedTemplatesInfo.Count > 0)
				{
					name = SelectedTemplatesInfo.First().Name;
				}
                return Resources.APMWebContent.APMWEBCODE_AK1_30.FormatInvariant(name);
			}
			return null;
		}
	}

	private SelectNodeTreeItem NodeInfo
	{
		get
		{
			if (ctrNodes.SelectedIndex == -1)
			{
				ctrNodes.SelectedIndex = 0;
			}
			return SelectedNodesInfo
				.FirstOrDefault(item => item.Id.ToString() == ctrNodes.SelectedValue);
		}
	}

	private List<SelectNodeTreeItem> Components
	{
		get
		{
			if (SelectedTemplatesInfo.Count > 0)
			{
				var cmps = new List<ComponentTemplate>();
				using (var bl = ServiceLocatorForWeb.GetServiceForWeb<IBusinessLayerFactory>().Create())
				{
					foreach (var tpl in SelectedTemplatesInfo)
					{
						var tmpl = bl.GetApplicationTemplate(tpl.Id);

						cmps.AddRange(tmpl.ComponentTemplates);
					}
				}
				return cmps
					.Select(item => new SelectNodeTreeItem((Int32)item.Id, item.Name) { CredentialId = item.CredentialSetId })
					.ToList();
			}
			if (SelectedComponentsInfo.Count > 0)
			{
				return SelectedComponentsInfo
					.Select(item => new SelectNodeTreeItem((Int32)item.Id, item.Name) { CredentialId = item.CredentialSetId })
					.ToList();
			}
			return null;
		}
	}

    private string DefaultNodeTypes
    {
        get
        {
            return CredentialOwner == "Core"
                ? Resources.APMWebContent.ApplicationTemplateAssignment_AgentWmi
                : Resources.APMWebContent.ApplicationTemplateAssignment_SnmpIcmp;
        }
    }

    #endregion

	#region Event Handlers

	protected override void OnInit(EventArgs e) 
	{
		ctrCreds.ValidationSummaryParentClientID = ClientID;

		base.OnInit(e);
	}

	protected void Page_Load(Object sender, EventArgs e)
	{
		if (Visible) 
		{
			ctrTest.Key = ctrValSummary.ValidationGroup = ctrCreds.ValidationGroupName = Key;

			if (!IsPostBack)
			{
				ctrCredCnt.Visible = ctrCreds.Visible = false;
				if (IsCoreCred)
				{
					ctrCredsTypes.Items.Add(CredCore);
				    ctrCredsTypes.Items.Add(ApplicationMode ? CredApplication : CredTemplate);
					ctrCredsTypes.Items.Add(CredCustom);

					ctrCredsTypes.SelectedIndex = 0;
				}
				else
				{
                    ctrCredsTypes.Items.Add(ApplicationMode ? CredApplication : CredTemplate);
					ctrCredsTypes.Items.Add(CredCustom);

					ctrCredsTypes.SelectedIndex = 1;
					ctrCredCnt.Visible = ctrCreds.Visible = true;
				}

			    var items = SelectedNodesInfo
			        .Select(item => new ListItem(@"<img src=""/Orion/StatusIcon.ashx?entity=Orion.Nodes&status={0}""/> {1}".FormatInvariant(item.Status, item.Name), item.Id.ToString()))
			        .ToArray();
			    ctrNodes.Items.AddRange(items);
			    ctrNodes.SelectedIndex = 0;
			}
			this.UpdateTestResult(null);
		}
	}

	protected void OnCredValidate_Click(object sender, EventArgs e)
	{
		this.UpdateTestResult("run-test");
	}

	protected void OnNodes_SelectedIndexChanged(Object sender, EventArgs e)
	{
		this.UpdateTestResult(null);
	}

	protected void OnCredsTypes_SelectedIndexChanged(Object sender, EventArgs e)
	{
		if (ctrCredsTypes.SelectedValue == CredCustom.Value)
		{
			ctrCredCnt.Visible = ctrCreds.Visible = true;
		}
		else 
		{
			ctrCredCnt.Visible = ctrCreds.Visible = false;
		}
		this.UpdateTestResult(null);
	}

	#endregion

	#region Helper Members

	private void UpdateTestResult(String action) 
	{
		if (Visible) 
		{
			Object credID = ComponentBase.TemplateCredentialsId;
			if (ctrCredsTypes.SelectedItem.Value == CredCore.Value)
			{
				credID = ComponentBase.NodeWmiCredentialsId;
			}
			else if (ctrCredsTypes.SelectedItem.Value == CredCustom.Value)
			{
				credID = ComponentBase.NewCredentialsId;
				
				var cred = ctrCreds.SelectedCredentialSet;
				if (cred.Id < 0) 
				{
					if (IsValid)
					{
						using (var bl = ServiceLocatorForWeb.GetServiceForWeb<IBusinessLayerFactory>().Create())
						{
							cred.Id = bl.CreateNewCredentialSet(cred);
							ctrCreds.ReloadCredentialSets();
						    ctrCreds.DataSource = cred;
						    ctrCreds.DataBindNewCredentialSetForm();
						}
					}
					else 
					{
						action = null;
					}
				}
			}

            if (!HideTestControl)
		    {
		        ctrTest.Initialize(ClientID, SelectedNodesInfo, Components, ApplicationMode);
		        ctrTest.Update(NodeInfo.Id, NodeInfo.Name, credID, action);
		    }
		}
	}

	public void ClearSession()
	{
		ctrTest.ClearSession();
	} 

	#endregion
}
