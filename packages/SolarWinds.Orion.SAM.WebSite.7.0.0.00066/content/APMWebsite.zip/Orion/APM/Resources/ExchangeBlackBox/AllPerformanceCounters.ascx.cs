﻿using System;
using SolarWinds.APM.BlackBox.Exchg.Common.ResourceMetadata;
using SolarWinds.Orion.Web.ResourcesMetadata;
using SolarWinds.Orion.Web.ResourcesMetadata.Enums;
using SolarWinds.Orion.Web.UI;

[ResourceMetadata(StandardMetadataPropertyName.Type, CoreMetadataTypeValues.Details)]
[ResourceMetadata(StandardMetadataPropertyName.IsCompatibleWithReporting, "false")]
public partial class Orion_APM_Resources_ExchangeBlackBox_AllPerformanceCounters : SolarWinds.APM.BlackBox.Exchg.Web.UI.ExchangeStatisticResourceBase
{
	protected override string DefaultTitle
	{
		get { return "Performance Counters"; }
	}

	public override ResourceLoadingMode ResourceLoadingMode
	{
		get { return ResourceLoadingMode.Ajax; }
	}

	protected string CustomApplicationType
	{
		get { return ExchangeStatistic.Application.CustomType; }
	}

	protected int ApplicationId
	{
		get { return ExchangeStatistic.ExchangeApplication.Id; }
	}

	protected int ApplicationItemId
	{
		get { return ExchangeStatistic.BaseComponent.ApplicationItemID ?? -1; }
	}

    protected bool IsApplicationItemSpecific
    {
        get { return ExchangeStatistic.IsApplicationItemSpecific; }
    }

	protected override void OnInit(EventArgs e)
	{
        base.OnInit(e);
        bool compatible = (this.ExchangeStatistic != null);
        this.incompatibleComponentPlaceHolder.Visible = !compatible;
        this.contentPlaceHolder.Visible = compatible;
    }
}