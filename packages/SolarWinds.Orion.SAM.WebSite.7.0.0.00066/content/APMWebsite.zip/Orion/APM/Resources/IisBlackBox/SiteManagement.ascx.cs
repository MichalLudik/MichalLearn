﻿using System;
using System.Collections.Generic;
using SolarWinds.APM.BlackBox.IIS.Web;
using SolarWinds.APM.Web;
using SolarWinds.Orion.Web.UI;
using SolarWinds.APM.Common.Models;

public partial class Orion_APM_Resources_IisBlackBox_SiteManagement : ApmBaseResource
{
    public override IEnumerable<Type> RequiredInterfaces
    {
        get { return new[] { typeof(ISiteProvider) }; }
    }

    public override string HelpLinkFragment
    {
        get { return "SAMAGAppInforIISSiteMgmtRes"; }
    }

    protected override string DefaultTitle
    {
		get { return "Site Management"; }
    }

    public override ResourceLoadingMode ResourceLoadingMode
    {
        get { return ResourceLoadingMode.Ajax; }
    }

    public Site ManagedSite
    {
        get { return GetInterfaceInstance<ISiteProvider>().IisSite; }
    }

    public bool HideManagementControls
    {
        get { return ApmRoleAccessor.AllowIisActionRights == false || ManagedSite.ApmStatus.Value == Status.Unmanaged; }
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        this.Visible = ApmRoleAccessor.AllowAdmin || ApmRoleAccessor.AllowIisActionRights;        
    }
}