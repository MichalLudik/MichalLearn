using System.Web.UI;

public partial class Orion_APM_MockupApplicationDetails : Page
{
}
