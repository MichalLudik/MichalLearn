﻿$(".ResourceColumn")
    .mouseenter(function() {
        $("#" + this.id).css("z-index", 2);
    })
    .mouseleave(function() {
        $("#" + this.id).css("z-index", "");
    });