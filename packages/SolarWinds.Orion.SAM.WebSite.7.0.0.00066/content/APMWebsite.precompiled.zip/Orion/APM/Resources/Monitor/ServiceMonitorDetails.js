﻿Ext.namespace('SW.APM');

SW.APM.ServicesMonitorDetailsHandlers = (function () {
    var appDetails = {};
    var service;
    var getServiceByName = function (name, services) {
    	service = null;
    	var lowerName = name.toLowerCase();
        Ext.each(services, function () {
        	if (this.Name.toLowerCase() == lowerName || this.DisplayName.toLowerCase() == lowerName) {
                service = this;
                return service;
            }
        });
        return service;
    };

    var showErrorMessage = function (message) {
        Ext.Msg.show({ title: "Service Error Details", msg: message, icon: Ext.Msg.INFO, buttons: Ext.Msg.OK });
    };
    
    var showErrorDialog = function (error) {
        Ext.Msg.show({ title: 'Error', msg: error, buttons: { ok: 'OK' }, width: 400, height: 150, icon: Ext.MessageBox.ERROR });
    };
    
    var dependencyDialog = function (action, msg, successAction, nodeId, credentialId, serviceName) {
        Ext.Msg.show({
            buttons: Ext.Msg.YESNO,
            title: action + ' related services?',
            msg: msg,
            icon: Ext.MessageBox.WARNING,
            width: 420,
            fn: function (btn) {
                if (btn == 'yes') {
                    successAction(nodeId, credentialId, serviceName);
                }
            }
        });
    };

    var getServiceDependenciesHtml = function (dependencies) {
        var depMsg = '';
        Ext.each(dependencies, function () {
            if (this.AcceptStop == true && this.State == "Running") {
                depMsg += '<li> -  ' + this.DisplayName + ' (' + this.Name + ')' + '</li>';
            }
        });
        if (depMsg != '') {
            return '<div style=\"max-height: 250px; overflow:auto; overflow-x:hidden; padding-top:5px\" ><ul>' + depMsg + '</ul></div>';
        } else {
            return depMsg;
        }
    };

    var renderService = function (service, serviceActionMessage, serviceErrorMessage) {
        var startStopRestartServiceContainer = $('#startStopRestartServiceContainer');

        if (startStopRestartServiceContainer[0]) {
            if (service.State == 'Stopped') {
                var startClick = 'SW.APM.ServicesMonitorDetailsHandlers.StartService (' + appDetails.NodeId + ',' + appDetails.CredentialId + ',\'' + appDetails.ServiceName.toString() + '\');';
                startStopRestartServiceContainer[0].innerHTML = '<a href="javascript:void(0)" onclick="return ' + startClick + '"><img alt="" src="/Orion/APM/Images/ProcessMonitor/icon_play.png" /> Start this service</a>';
            }
            if (service.State == 'Running') {
                var stopClick = 'SW.APM.ServicesMonitorDetailsHandlers.StopService (' + appDetails.NodeId + ',' + appDetails.CredentialId + ',\'' + appDetails.ServiceName.toString() + '\');',
                    restartClick = 'SW.APM.ServicesMonitorDetailsHandlers.RestartService (' + appDetails.NodeId + ',' + appDetails.CredentialId + ',\'' + appDetails.ServiceName.toString() + '\');';

                var stopLink = '<a href="javascript:void(0)" onclick="return ' + stopClick + '"><img alt="" src="/Orion/APM/Images/stop_service.png" /> Stop this service</a>',
                    restartLink = '<a href="javascript:void(0)" onclick="return ' + restartClick + '"><img alt="" src="/Orion/APM/Images/restart_service.png" /> Restart this service</a>';

                startStopRestartServiceContainer[0].innerHTML = restartLink + '<br />' + stopLink;
            }
        }
        renderServiceStatus(service.State, serviceActionMessage, serviceErrorMessage);
    };

    var renderServiceStatus = function (status, serviceActionMessage, serviceErrorMessage) {
        var res;
        var processingAction = $('#serviceStatusContainer');
        if (!Ext.isDefined(processingAction[0])) return;
        
        switch (status) {
            case 'Running':
                res = '<img class="row-img" src="/Orion/Images/icon_run.gif"/>&nbsp;&nbsp;' + status;
                break;
            case 'Stopped':
                res = '<img class="row-img" src="/Orion/Images/Cmd-Stopped.png"/>&nbsp;&nbsp;' + status;
                break;
            default:
                res = status;
                break;
        }

        if (serviceActionMessage != null || serviceErrorMessage != null) {
            var msg = serviceActionMessage ? serviceActionMessage : serviceErrorMessage,
                errorBoxHtml = '<div class="status-details-container" status="NotAvailable"><span>{0}</span><label>{1}</label></div>',
                spacing = Array(6).join('&nbsp;');

            if (res != '') res += '</br>';

            res += String.format(errorBoxHtml, spacing, msg);

            processingAction[0].innerHTML = res;

            SW.APM.TrimStatusDetails();
        } else {
            processingAction[0].innerHTML = res;
        }
    };

    var stopService = function (nodeId, credentialId, serviceName) {
        var processingAction = $('#serviceStatusContainer');
        if (!Ext.isDefined(processingAction[0])) return;
     
        if (service && service.Unmanaged == true) {
            showErrorDialog('The <b>' + service.DisplayName + '</b>' + ' service cannot be stopped because this is a critical system service. Stopping this service would cause system instability.');
            return;
        }
    
        var action = "Stopping...";
        processingAction[0].innerHTML = "<img src='/Orion/APM/Images/loading_gen_16x16.gif'></img>" + action;
        var parameters = "{nodeId:" + nodeId + ",'credentialId':'" + credentialId + "','serviceName':'" + serviceName + "'}";
        $.ajax({
            type: 'Post',
            data: parameters,
            headers: { 'Content-Type': 'application/json; charset=utf-8' },
            dataType: "json",
            url: '/Orion/APM/Services/Services.asmx/StopService',
            success: function (data) {
                processingAction[0].innerHTML = "";
                service = getServiceByName(serviceName, data.d.Services);
                var serviceActionMessage = null, serviceErrorMessage = null;
                if (service && service.ActionExitCode != 0 && service.ActionMessage) { serviceActionMessage = service.ActionMessage;}

                if (data.d.ErrorMessage != null && data.d.PollStatus != 0) { serviceErrorMessage = data.d.ErrorMessage;}

                if (service) { renderService(service, serviceActionMessage, serviceErrorMessage); }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                processingAction[0].innerHTML = "";
                renderServiceStatus("",thrownError, null);
            }
        });
    };

    var restartService = function (nodeId, credentialId, serviceName) {       
        var processingAction = $('#serviceStatusContainer');
        if (!Ext.isDefined(processingAction[0])) return;

        if (service && service.Unmanaged == true) {
            showErrorDialog('The <b>' + service.DisplayName + '</b>' + ' service cannot be restarted because this is a critical system service. Restarting this service would cause system instability.');
            return;
        }
        
        var action = "Restarting...";
        processingAction[0].innerHTML = "<img src='/Orion/APM/Images/loading_gen_16x16.gif'></img>" + action;
        var parameters = "{nodeId:" + nodeId + ",'credentialId':'" + credentialId + "','serviceName':'" + serviceName + "'}";
        $.ajax({
            type: 'Post',
            data: parameters,
            headers: { 'Content-Type': 'application/json; charset=utf-8' },
            dataType: "json",
            url: '/Orion/APM/Services/Services.asmx/RestartService',
            success: function (data) {
                processingAction[0].innerHTML = "";
                service = getServiceByName(serviceName, data.d.Services);
                var serviceActionMessage = null, serviceErrorMessage = null;

                if (service && service.ActionExitCode != 0 && service.ActionMessage) { serviceActionMessage = service.ActionMessage; }

                if (data.d.ErrorMessage != null && data.d.PollStatus != 0) { serviceErrorMessage = data.d.ErrorMessage; }

                if (service) { renderService(service, serviceActionMessage, serviceErrorMessage); }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                processingAction[0].innerHTML = "";
                renderServiceStatus("", thrownError, null);
            }
        });
    };

    return {
        init: function () {
        },
        GetServicesInfo: function (nodeId, credentialId, serviceName) {
            appDetails.NodeId = nodeId;
            appDetails.CredentialId = credentialId;
            appDetails.ServiceName = serviceName;
            var processingAction = $('#serviceStatusContainer');
            if (!Ext.isDefined(processingAction[0])) return;
            
            var action = " Loading...";
            processingAction[0].innerHTML = "<img src='/Orion/APM/Images/loading_gen_16x16.gif'></img>" + action;
            var parameters = "{nodeId:" + nodeId + ",'credentialId':'" + credentialId + "','serviceName':'" + serviceName + "'}";
            $.ajax({
                type: 'Post',
                data: parameters,
                headers: { 'Content-Type': 'application/json; charset=utf-8' },
                dataType: "json",
                url: '/Orion/APM/Services/Services.asmx/GetServiceInfoSync',
                success: function (data) {
                    processingAction[0].innerHTML = "";
                    service = getServiceByName(serviceName, data.d.Services);
                    if (service && service.ActionExitCode != 0 && service.ActionMessage) { renderServiceStatus("", service.ActionMessage, null); }
                    
                    if (data.d.ErrorMessage != null && data.d.PollStatus != 0) { renderServiceStatus("", data.d.ErrorMessage, null); }

                    if (service) { renderService(service); }  
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    processingAction[0].innerHTML = "";
                    renderServiceStatus("", thrownError, null);
                }
            });
        },

        StartService: function (nodeId, credentialId, serviceName) {
            
            if (SW.APM.ServicesMonitorDetailsHandlers.IsDemo == 'true') {
                DemoModeAction("Service_Component_Details_Start_Service");
                return;
            }
            
            var processingAction = $('#serviceStatusContainer');
            if (!Ext.isDefined(processingAction[0])) return;
            
            var action = "Starting...";
            processingAction[0].innerHTML = "<img src='/Orion/APM/Images/loading_gen_16x16.gif'></img>" + action;

            var parameters = "{nodeId:" + nodeId + ",'credentialId':'" + credentialId + "','serviceName':'" + serviceName + "'}";
            $.ajax({
                type: 'Post',
                data: parameters,
                headers: { 'Content-Type': 'application/json; charset=utf-8' },
                dataType: "json",
                url: '/Orion/APM/Services/Services.asmx/StartService',
                success: function (data) {
                    processingAction[0].innerHTML = "";
                    service = getServiceByName(serviceName, data.d.Services);
                    var serviceActionMessage = null,  serviceErrorMessage = null;
                    if (service && service.ActionExitCode != 0 && service.ActionMessage) { serviceActionMessage = service.ActionMessage;}

                    if (data.d.ErrorMessage != null && data.d.PollStatus != 0) { serviceErrorMessage = data.d.ErrorMessage;}
                 
                    if (service) { renderService(service, serviceActionMessage, serviceErrorMessage); }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    processingAction[0].innerHTML = "";
                    renderServiceStatus("", thrownError, null);
                }
            });
        },

        RestartService: function (nodeId, credentialId, serviceName) {

            if (SW.APM.ServicesMonitorDetailsHandlers.IsDemo == 'true') {
                DemoModeAction("Service_Component_Details_Restart_Service");
                return;
            }
            
            if (service && service.Dependencies && service.Dependencies.length > 0) {
                var msg = '<b>Do you want to restart "' + service.DisplayName + '" and all dependent services?</b><br/><br/> <div>The following services are dependent and will be restarted:<br/>';
                var depHtml = getServiceDependenciesHtml(service.Dependencies);

                if (depHtml != '') {
                    var resMsg = msg + depHtml + '</div>';
                    dependencyDialog('Restart', resMsg, restartService, nodeId, credentialId, serviceName);
                }
                else { restartService(nodeId, credentialId, serviceName); }
            }
            else { restartService(nodeId, credentialId, serviceName); }
        },

        StopService: function (nodeId, credentialId, serviceName) {

            if (SW.APM.ServicesMonitorDetailsHandlers.IsDemo == 'true') {
                DemoModeAction("Service_Component_Details_Stop_Service");
                return;
            }

            if (service && service.Dependencies && service.Dependencies.length > 0) {
                var msg = '<b>Do you want to stop "' + service.DisplayName + '" and all dependent services?</b><br/><br/> <div>The following services are dependent and will be stopped:<br/>';
                var depHtml = getServiceDependenciesHtml(service.Dependencies);

                if (depHtml != '') {
                    var resMsg = msg + depHtml + '</div>';
                    dependencyDialog('Stop', resMsg, stopService, nodeId, credentialId, serviceName);
                }
                else { stopService(nodeId, credentialId, serviceName); }
            }
            else { stopService(nodeId, credentialId, serviceName); }
        }
    };
})();