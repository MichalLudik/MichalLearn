/// <reference path="../Edit.d.ts" />
module SW.APM.EditApp.Editors.CustomPowerShell {

    var Props = Editors.initProps({
        template: [
            { id: 'Desc', name: 'UserDescription' },
            { id: 'Disabled', name: 'IsDisabled' },
            { id: 'Notes', name: 'UserNote' }
        ]
    });

    var PropsDev = Editors.initProps({
        template: [
            { id: 'Credential', name: 'CredentialSetId' }
        ],
        settings: [
            { id: 'Script', name: 'ScriptBody' }
        ]
    });

    var PropsDevTemplate = Editors.initProps({
        settings: [
            { name: 'VisibilityMode' }
        ],
        template: [
            { id: 'CanBeDisabled', name: '_BB_CanBeDisabled' }
        ]
    });


    function getProps(isDev: boolean, isTemplate: boolean, isBlackBoxEdit: boolean, thrKeys: string[]): PropertyInterface[] {
        var props = Props.slice(), propsThr;
        if (isBlackBoxEdit) {
            props.some(function (prop) {
                if (prop.name === 'UserDescription') {
                    prop.readonly = true;
                    return true;
                }
            });
        }
        if (isDev) {
            props = props.concat(PropsDev);
            if (isTemplate) {
                props = props.concat(PropsDevTemplate);
            }
        }
        propsThr = Editors.initPropsThr(thrKeys);
        props = props.concat(propsThr);
        return props;
    }

    function initSingle(cmpId: number, isDev: boolean, isTemplate: boolean, isBlackBoxEdit: boolean, thrKeys: string[]) {

        function onLoad(model: ModelInterface) {
            var cmp = <ComponentInterface> this;
            var tpl = model.getComponentTemplate(cmp.TemplateId);

            Editors.chunkInitSingle({
                cmp: cmp,
                cmpId: cmpId,
                template: tpl,
                props: getProps(isDev, isTemplate, isBlackBoxEdit, thrKeys)
            });
        }

        function onSave(model: ModelInterface) {
            Editors.chunkUpdateSingle({
                cmp: <ComponentInterface> this,
                cmpId: cmpId,
                isTemplate: !model.haveTemplate(),
                props: getProps(isDev, isTemplate, isBlackBoxEdit, thrKeys)
            });
        }

        EditApp.Grid.registerEditor(cmpId, onLoad, onSave);
    }

    export function init(isMulti, cmpId, unused_cmpIds, isDev, isTemplate, isBlackBoxEdit, thrKeys) {
        isMulti = Editors.parseBool(isMulti);
        isDev = Editors.parseBool(isDev);
        isTemplate = Editors.parseBool(isTemplate);
        isBlackBoxEdit = Editors.parseBool(isBlackBoxEdit);
        cmpId = Editors.parseId(cmpId);
        thrKeys = Editors.parseList(thrKeys);
        if (!isMulti) {
            initSingle(cmpId, isDev, isTemplate, isBlackBoxEdit, thrKeys);
        }
    }

}
