﻿Ext.ns("SW.APM.RealTimeEvents");

window.RTWEM = SW.APM.RealTimeEvents;

window.RTWEM_IsLog = Ext.isDefined(Ext.global.console);
window.RTWEM_Log = function (message) {
	if (RTWEM_IsLog) {
		Ext.global.console.warn(message);
	}
}

window.RTWEM_JOB_STATUS_INIT = 1;
window.RTWEM_JOB_STATUS_ERROR = 3;

window.RTWEM_PAGE_SIZE = 70;

window.RTWEM_NA = "@{R=APM.Strings;K=APMLIBCODE_AK1_2;E=js}";

window.RTWEM_ErrorTitle = "Event Viewer Error";
window.RTWEM_NumberOfEventsTpl = "Number of event(s): {0}";

window.RTWEM_LoadMsgInit = "";
window.RTWEM_LoadMsgDefault = "Loading. Please wait...";
window.RTWEM_LoadMsgRestart = "Polling restarting. Please wait...";
window.RTWEM_LoadMsgStartNew = "New polling starting. Please wait...";

window.RTWEM_Cancel = "@{R=APM.Strings;K=APMWEBJS_VB1_39;E=js}";
window.RTWEM_TryDifCred = "@{R=APM.Strings;K=APMWEBJS_AK1_42;E=js}";
window.RTWEM_MonitoringInfo = "over {0} using \"{1}\" credentials...";

window.RTWEM_FilterTitle = "Events Filter";
window.RTWEM_FilterSubTitleTpl = "Filter for <b>{0}</b> log";
window.RTWEM_FilterLogLabel = "Select Log Type:";
window.RTWEM_FilterSourceLabel = "Event Sources:"
window.RTWEM_FilterLevelLabel = "Event Levels:"

window.RTWEM_StartMonitoring = "@{R=APM.Strings;K=APMWEBJS_AK1_34;E=js}";
window.RTWEM_SelectAll = "Select all";
window.RTWEM_SelectNone = "Select none";
window.RTWEM_StartPolling = "@{R=APM.Strings;K=APMWEBJS_AK1_56;E=js}";
window.RTWEM_PausePolling = "@{R=APM.Strings;K=APMWEBJS_AK1_25;E=js}";
window.RTWEM_UseDifCred = "@{R=APM.Strings;K=APMWEBJS_AK1_26;E=js}";
window.RTWEM_RestartPolling = "Restart polling";
window.RTWEM_RestartPollingTip = "Clear cache and restart polling";
window.RTWEM_Relogin = "Relogin";

window.RTWEM_ErrorTimeout = "Timeout occurred during request to server. Possible reasons:<br/>" +
	"&nbsp;&nbsp;&nbsp;1. Session timeout. Your session has expired. Please press \"Relogin\" button.<br/>" +
	"&nbsp;&nbsp;&nbsp;2. Request timeout (you may have too many pre-cached events). Please press \"Restart polling\" button.";

window.RTWEM_EvtDetailsDlgTitle = "@{R=APM.Strings;K=APMWEBJS_PV0_11;E=js}";
window.RTWEM_EvtLevel = "@{R=APM.Strings;K=APMWEBJS_PV0_1;E=js}";
window.RTWEM_EvtEventId = "@{R=APM.Strings;K=APMWEBJS_PV0_2;E=js}";
window.RTWEM_EvtDate = "@{R=APM.Strings;K=APMWEBJS_PV0_3;E=js}";
window.RTWEM_EvtLog = "@{R=APM.Strings;K=APMWEBJS_PV0_5;E=js}";
window.RTWEM_EvtSource = "@{R=APM.Strings;K=APMWEBJS_PV0_6;E=js}";
window.RTWEM_EvtComputer = "@{R=APM.Strings;K=APMWEBJS_PV0_7;E=js}";
window.RTWEM_EvtUser = "@{R=APM.Strings;K=APMWEBJS_PV0_8;E=js}";